# YoutubeMixBlocker


A simple chrome extension to block youtube mixes.
